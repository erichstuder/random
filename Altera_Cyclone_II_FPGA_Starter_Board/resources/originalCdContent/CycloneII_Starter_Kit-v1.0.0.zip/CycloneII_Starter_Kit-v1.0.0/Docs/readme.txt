Cyclone II FPGA Starter Development Kit v1.0.0 README File
==========================================================

Last Minute Notes - 16Oct06
===========================
The Cyclone II FPGA Starter Development Kit contains a tutorial directory with pdf tutorials that cover various
tools, ip, and boards that Altera provides.  In many cases the tutorials will reference boards other than the
Cyclone II FPGA Starter Development Board as a platform on which to learn.  Time did not allow for us to update
each of these documents to call out the Cyclone II FPGA Starter Development Board specifically, but we still felt
it was useful to include these tutorials.

Revision History
================
    Version 1.0.0: Initial release
                   

Contacting Altera
=================
If you have additional questions, contact Altera Applications using one of 
the following methods:

Technical Support Hotline 	(800) 800-EPLD (U.S.)
                                (408) 544-7000 (Internationally)

Online Technical Support        http://www.altera.com/mysupport

World-Wide Web 	                http://www.altera.com


Copyright (c) 2006 Altera Corporation. All rights reserved.
