/////////////   Controller Command	////////////////////////
parameter CMD_READ		=	3'h0;
parameter CMD_WRITE 	= 	3'h1;
parameter CMD_BLK_ERA	= 	3'h2;
parameter CMD_SEC_ERA 	= 	3'h3;
parameter CMD_CHP_ERA	= 	3'h4;
parameter CMD_ENTRY_ID	= 	3'h5;
parameter CMD_RESET		= 	3'h6;
